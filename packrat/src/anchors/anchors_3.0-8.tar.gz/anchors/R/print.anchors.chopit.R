print.anchors.chopit <- function(x,...) {
  summary(x)
}
