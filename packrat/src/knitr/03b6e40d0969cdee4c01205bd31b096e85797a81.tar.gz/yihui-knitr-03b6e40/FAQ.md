This page has been moved to <https://yihui.name/knitr/faq/>.
