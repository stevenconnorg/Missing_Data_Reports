The source of the **knitr** website has been moved to https://github.com/rbind/yihui/tree/master/content/knitr
